#pragma once
#include <string>
using namespace std;
class Tipo_dato
{
public:
	int id;
	string descripcion;
public:
	tipodato(void)
		~tipodato(void)
		void set_tipodato(int id, string desc);

};

